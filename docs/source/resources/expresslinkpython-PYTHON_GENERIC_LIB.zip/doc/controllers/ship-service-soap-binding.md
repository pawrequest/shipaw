# Ship Service Soap Binding

```python
ship_service_soap_binding_controller = client.ship_service_soap_binding
```

## Class Name

`ShipServiceSoapBindingController`

## Methods

* [Create Shipment](../../doc/controllers/ship-service-soap-binding.md#create-shipment)
* [Create Print](../../doc/controllers/ship-service-soap-binding.md#create-print)
* [Print Label](../../doc/controllers/ship-service-soap-binding.md#print-label)
* [Print Document](../../doc/controllers/ship-service-soap-binding.md#print-document)
* [Create Manifest](../../doc/controllers/ship-service-soap-binding.md#create-manifest)
* [Print Manifest](../../doc/controllers/ship-service-soap-binding.md#print-manifest)
* [Return Shipment](../../doc/controllers/ship-service-soap-binding.md#return-shipment)
* [Find](../../doc/controllers/ship-service-soap-binding.md#find)
* [CC Reserve](../../doc/controllers/ship-service-soap-binding.md#cc-reserve)
* [Cancel Shipment](../../doc/controllers/ship-service-soap-binding.md#cancel-shipment)


# Create Shipment

```python
def create_shipment(self,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateShipmentRequest`](../../doc/models/create-shipment-request.md) | Body, Required | - |

## Response Type

[`CreateShipmentReply`](../../doc/models/create-shipment-reply.md)

## Example Usage

```python
body = CreateShipmentRequest(
    authentication=Authentication(
        user_name='UserName4',
        password='Password8'
    ),
    requested_shipment=RequestedShipment(
        shipment_type='ShipmentType4',
        contract_number='ContractNumber2',
        service_code='ServiceCode0',
        recipient_contact=Contact(
            business_name='BusinessName6'
        ),
        recipient_address=Address(
            address_line_1='AddressLine10',
            country='Country8'
        )
    )
)

result = ship_service_soap_binding_controller.create_shipment(body)
print(result)
```


# Create Print

```python
def create_print(self,
                body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePrintRequest`](../../doc/models/create-print-request.md) | Body, Required | - |

## Response Type

[`CreatePrintReply`](../../doc/models/create-print-reply.md)

## Example Usage

```python
body = CreatePrintRequest(
    authentication=Authentication(
        user_name='UserName4',
        password='Password8'
    ),
    requested_shipment=RequestedShipment(
        shipment_type='ShipmentType4',
        contract_number='ContractNumber2',
        service_code='ServiceCode0',
        recipient_contact=Contact(
            business_name='BusinessName6'
        ),
        recipient_address=Address(
            address_line_1='AddressLine10',
            country='Country8'
        )
    )
)

result = ship_service_soap_binding_controller.create_print(body)
print(result)
```


# Print Label

```python
def print_label(self,
               body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PrintLabelRequest1`](../../doc/models/print-label-request-1.md) | Body, Required | - |

## Response Type

[`PrintLabelReply1`](../../doc/models/print-label-reply-1.md)

## Example Usage

```python
body = PrintLabelRequest1(
    print_label_request=PrintLabelRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        shipment_number='ShipmentNumber2'
    )
)

result = ship_service_soap_binding_controller.print_label(body)
print(result)
```


# Print Document

```python
def print_document(self,
                  body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PrintDocumentRequest1`](../../doc/models/print-document-request-1.md) | Body, Required | - |

## Response Type

[`PrintDocumentReply1`](../../doc/models/print-document-reply-1.md)

## Example Usage

```python
body = PrintDocumentRequest1(
    print_document_request=PrintDocumentRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        shipment_number='ShipmentNumber4',
        document_type=70
    )
)

result = ship_service_soap_binding_controller.print_document(body)
print(result)
```


# Create Manifest

```python
def create_manifest(self,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateManifestRequest1`](../../doc/models/create-manifest-request-1.md) | Body, Required | - |

## Response Type

[`CreateManifestReply1`](../../doc/models/create-manifest-reply-1.md)

## Example Usage

```python
body = CreateManifestRequest1(
    create_manifest_request=CreateManifestRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        )
    )
)

result = ship_service_soap_binding_controller.create_manifest(body)
print(result)
```


# Print Manifest

```python
def print_manifest(self,
                  body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PrintManifestRequest1`](../../doc/models/print-manifest-request-1.md) | Body, Required | - |

## Response Type

[`PrintManifestReply1`](../../doc/models/print-manifest-reply-1.md)

## Example Usage

```python
body = PrintManifestRequest1(
    print_manifest_request=PrintManifestRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        manifest_number='ManifestNumber6'
    )
)

result = ship_service_soap_binding_controller.print_manifest(body)
print(result)
```


# Return Shipment

```python
def return_shipment(self,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReturnShipmentRequest1`](../../doc/models/return-shipment-request-1.md) | Body, Required | - |

## Response Type

[`ReturnShipmentReply1`](../../doc/models/return-shipment-reply-1.md)

## Example Usage

```python
body = ReturnShipmentRequest1(
    return_shipment_request=ReturnShipmentRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        shipment_number='ShipmentNumber2',
        collection_time=DateTimeRange(
            mfrom=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            to=dateutil.parser.parse('2016-03-13T12:52:32.123Z')
        )
    )
)

result = ship_service_soap_binding_controller.return_shipment(body)
print(result)
```


# Find

```python
def find(self,
        body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FindRequest`](../../doc/models/find-request.md) | Body, Required | - |

## Response Type

[`FindReply`](../../doc/models/find-reply.md)

## Example Usage

```python
body = FindRequest(
    authentication=Authentication(
        user_name='UserName4',
        password='Password8'
    ),
    convenient_collect=ConvenientCollect(),
    specified_post_office=SpecifiedPostOffice(),
    paf=PAF(
        postcode='Postcode8',
        count=158,
        specified_neighbour=[
            SpecifiedNeighbour()
        ]
    ),
    safe_places=False,
    nominated_delivery_dates=NominatedDeliveryDates(),
    postcode_exclusion=PostcodeExclusion()
)

result = ship_service_soap_binding_controller.find(body)
print(result)
```


# CC Reserve

```python
def cc_reserve(self,
              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CCReserveRequest1`](../../doc/models/cc-reserve-request-1.md) | Body, Required | - |

## Response Type

[`CCReserveReply1`](../../doc/models/cc-reserve-reply-1.md)

## Example Usage

```python
body = CCReserveRequest1(
    cc_reserve_request=CCReserveRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        booking_reference='BookingReference6'
    )
)

result = ship_service_soap_binding_controller.cc_reserve(body)
print(result)
```


# Cancel Shipment

```python
def cancel_shipment(self,
                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CancelShipmentRequest1`](../../doc/models/cancel-shipment-request-1.md) | Body, Required | - |

## Response Type

[`CancelShipmentReply1`](../../doc/models/cancel-shipment-reply-1.md)

## Example Usage

```python
body = CancelShipmentRequest1(
    cancel_shipment_request=CancelShipmentRequest(
        authentication=Authentication(
            user_name='UserName4',
            password='Password8'
        ),
        shipment_number='ShipmentNumber4'
    )
)

result = ship_service_soap_binding_controller.cancel_shipment(body)
print(result)
```

