
# Cancel Shipment Reply 1

## Structure

`CancelShipmentReply1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel_shipment_reply` | [`CancelShipmentReply`](../../doc/models/cancel-shipment-reply.md) | Required | - |

## Example (as XML)

```xml
<CancelShipmentReply>
  <CancelShipmentReply>
    <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Alert>
        <tns:Code>6</tns:Code>
        <tns:Message>Message0</tns:Message>
        <tns:Type>ERROR</tns:Type>
      </tns:Alert>
    </tns:Alerts>
    <tns:CompletedCancel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:CompletedCancelInfo>
        <tns:Status>Status4</tns:Status>
        <tns:ShipmentNumber>ShipmentNumber6</tns:ShipmentNumber>
      </tns:CompletedCancelInfo>
    </tns:CompletedCancel>
  </CancelShipmentReply>
</CancelShipmentReply>
```

