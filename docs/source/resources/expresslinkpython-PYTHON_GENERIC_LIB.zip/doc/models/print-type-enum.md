
# Print Type Enum

## Enumeration

`PrintTypeEnum`

## Fields

| Name |
|  --- |
| `ALL_PARCELS` |
| `SINGLE_PARCEL` |

