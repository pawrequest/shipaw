
# Department

## Structure

`Department`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `department_id` | `List[int]` | Optional | - |
| `service_codes` | [`List[ServiceCodes]`](../../doc/models/service-codes.md) | Optional | - |
| `nominated_delivery_date_list` | [`NominatedDeliveryDateList`](../../doc/models/nominated-delivery-date-list.md) | Optional | - |

## Example (as XML)

```xml
<tns:Department xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:DepartmentID xmlns:tns="http://www.parcelforce.net/ws/ship/v14">138</tns:DepartmentID>
  <tns:DepartmentID xmlns:tns="http://www.parcelforce.net/ws/ship/v14">139</tns:DepartmentID>
  <tns:DepartmentID xmlns:tns="http://www.parcelforce.net/ws/ship/v14">140</tns:DepartmentID>
  <tns:ServiceCodes xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
    <tns:ServiceCode>ServiceCode3</tns:ServiceCode>
    <tns:ServiceCode>ServiceCode4</tns:ServiceCode>
  </tns:ServiceCodes>
  <tns:NominatedDeliveryDateList xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
    <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
  </tns:NominatedDeliveryDateList>
</tns:Department>
```

