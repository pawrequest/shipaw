
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_line_1` | `str` | Required | - |
| `address_line_2` | `str` | Optional | - |
| `address_line_3` | `str` | Optional | - |
| `town` | `str` | Optional | - |
| `postcode` | `str` | Optional | - |
| `country` | `str` | Required | - |

## Example (as XML)

```xml
<tns:Address xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:AddressLine1 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">AddressLine14</tns:AddressLine1>
  <tns:AddressLine2 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">AddressLine28</tns:AddressLine2>
  <tns:AddressLine3 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">AddressLine30</tns:AddressLine3>
  <tns:Town xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Town2</tns:Town>
  <tns:Postcode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Postcode4</tns:Postcode>
  <tns:Country xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Country2</tns:Country>
</tns:Address>
```

