
# Create Manifest Request

## Structure

`CreateManifestRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `department_id` | `int` | Optional | - |

## Example (as XML)

```xml
<tns:CreateManifestRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:DepartmentId xmlns:tns="http://www.parcelforce.net/ws/ship/v14">122</tns:DepartmentId>
</tns:CreateManifestRequest>
```

