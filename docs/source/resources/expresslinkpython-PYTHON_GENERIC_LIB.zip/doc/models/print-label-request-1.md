
# Print Label Request 1

## Structure

`PrintLabelRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_label_request` | [`PrintLabelRequest`](../../doc/models/print-label-request.md) | Required | - |

## Example (as XML)

```xml
<PrintLabelRequest1>
  <tns:PrintLabelRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
    <tns:PrintFormat>PrintFormat4</tns:PrintFormat>
    <tns:BarcodeFormat>BarcodeFormat4</tns:BarcodeFormat>
    <tns:PrintType>ALL_PARCELS</tns:PrintType>
  </tns:PrintLabelRequest>
</PrintLabelRequest1>
```

