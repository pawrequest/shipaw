
# Content Details

## Structure

`ContentDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `content_detail` | [`List[ContentDetail]`](../../doc/models/content-detail.md) | Required | - |

## Example (as XML)

```xml
<tns:ContentDetails xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ContentDetail xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:CountryOfManufacture>CountryOfManufacture0</tns:CountryOfManufacture>
    <tns:CountryOfOrigin>CountryOfOrigin2</tns:CountryOfOrigin>
    <tns:ManufacturersName>ManufacturersName2</tns:ManufacturersName>
    <tns:Description>Description2</tns:Description>
    <tns:UnitWeight>127.88</tns:UnitWeight>
    <tns:UnitQuantity>198</tns:UnitQuantity>
    <tns:UnitValue>157.56</tns:UnitValue>
    <tns:Currency>Currency2</tns:Currency>
    <tns:TariffCode>TariffCode6</tns:TariffCode>
    <tns:TariffDescription>TariffDescription0</tns:TariffDescription>
    <tns:ArticleReference>ArticleReference4</tns:ArticleReference>
  </tns:ContentDetail>
</tns:ContentDetails>
```

