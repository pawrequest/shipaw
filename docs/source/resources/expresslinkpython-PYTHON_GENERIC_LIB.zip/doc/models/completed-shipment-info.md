
# Completed Shipment Info

## Structure

`CompletedShipmentInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lead_shipment_number` | `str` | Optional | - |
| `delivery_date` | `date` | Optional | - |
| `status` | `str` | Required | - |
| `completed_shipments` | [`CompletedShipments`](../../doc/models/completed-shipments.md) | Required | - |
| `requested_shipment` | [`RequestedShipment`](../../doc/models/requested-shipment.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedShipmentInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Status xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Status0</tns:Status>
  <tns:CompletedShipments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:CompletedShipment>
      <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
      <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
      <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
      <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
    </tns:CompletedShipment>
  </tns:CompletedShipments>
  <tns:RequestedShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:DepartmentId>156</tns:DepartmentId>
    <tns:ShipmentType>ShipmentType4</tns:ShipmentType>
    <tns:ContractNumber>ContractNumber2</tns:ContractNumber>
    <tns:RequestId>112</tns:RequestId>
    <tns:ServiceCode>ServiceCode0</tns:ServiceCode>
    <tns:PrePrinted>false</tns:PrePrinted>
    <tns:ShippingDate>2016-03-13</tns:ShippingDate>
    <tns:JobReference>JobReference8</tns:JobReference>
    <tns:RecipientContact>
      <tns:BusinessName>BusinessName6</tns:BusinessName>
      <tns:ContactName>ContactName4</tns:ContactName>
      <tns:EmailAddress>EmailAddress2</tns:EmailAddress>
      <tns:Telephone>Telephone2</tns:Telephone>
      <tns:Fax>Fax2</tns:Fax>
      <tns:MobilePhone>MobilePhone6</tns:MobilePhone>
    </tns:RecipientContact>
    <tns:RecipientAddress>
      <tns:AddressLine1>AddressLine10</tns:AddressLine1>
      <tns:AddressLine2>AddressLine24</tns:AddressLine2>
      <tns:AddressLine3>AddressLine36</tns:AddressLine3>
      <tns:Town>Town8</tns:Town>
      <tns:Postcode>Postcode0</tns:Postcode>
      <tns:Country>Country8</tns:Country>
    </tns:RecipientAddress>
  </tns:RequestedShipment>
  <tns:LeadShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">LeadShipmentNumber2</tns:LeadShipmentNumber>
  <tns:DeliveryDate xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13</tns:DeliveryDate>
</tns:CompletedShipmentInfo>
```

