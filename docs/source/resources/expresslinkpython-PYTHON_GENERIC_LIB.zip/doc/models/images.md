
# Images

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | [`List[Image]`](../../doc/models/image.md) | Required | - |

## Example (as XML)

```xml
<tns:Images xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Image xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Name>Name6</tns:Name>
    <tns:Data>Data0</tns:Data>
  </tns:Image>
</tns:Images>
```

