
# CC Reserve Request

## Structure

`CCReserveRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `booking_reference` | `str` | Required | - |

## Example (as XML)

```xml
<tns:CCReserveRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:BookingReference xmlns:tns="http://www.parcelforce.net/ws/ship/v14">BookingReference6</tns:BookingReference>
</tns:CCReserveRequest>
```

