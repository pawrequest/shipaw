
# Return Shipment Reply

## Structure

`ReturnShipmentReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_shipment_info` | [`CompletedReturnInfo`](../../doc/models/completed-return-info.md) | Optional | - |

## Example (as XML)

```xml
<tns:ReturnShipmentReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:CompletedShipmentInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Status>Status0</tns:Status>
    <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
    <tns:CollectionTime>
      <tns:From>2016-03-13T12:52:32.123Z</tns:From>
      <tns:To>2016-03-13T12:52:32.123Z</tns:To>
    </tns:CollectionTime>
  </tns:CompletedShipmentInfo>
</tns:ReturnShipmentReply>
```

