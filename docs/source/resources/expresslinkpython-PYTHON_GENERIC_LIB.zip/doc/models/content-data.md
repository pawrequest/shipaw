
# Content Data

## Structure

`ContentData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | - |
| `data` | `str` | Required | - |

## Example (as XML)

```xml
<tns:ContentData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Name xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Name4</tns:Name>
  <tns:Data xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Data0</tns:Data>
</tns:ContentData>
```

