
# Document

## Structure

`Document`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | `binary` | Required | - |

## Example (as XML)

```xml
<tns:Document xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Data xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Data0</tns:Data>
</tns:Document>
```

