
# Safe Place List

## Structure

`SafePlaceList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `safe_place` | `List[str]` | Optional | - |

## Example (as XML)

```xml
<tns:SafePlaceList xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:SafePlace xmlns:tns="http://www.parcelforce.net/ws/ship/v14">SafePlace3</tns:SafePlace>
  <tns:SafePlace xmlns:tns="http://www.parcelforce.net/ws/ship/v14">SafePlace4</tns:SafePlace>
</tns:SafePlaceList>
```

