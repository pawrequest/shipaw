
# Hazardous Goods

## Structure

`HazardousGoods`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hazardous_good` | [`List[HazardousGood]`](../../doc/models/hazardous-good.md) | Required | - |

## Example (as XML)

```xml
<tns:HazardousGoods xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:HazardousGood xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:LQDGUNCode>LQDGUNCode8</tns:LQDGUNCode>
    <tns:LQDGDescription>LQDGDescription6</tns:LQDGDescription>
    <tns:LQDGVolume>86.12</tns:LQDGVolume>
    <tns:Firearms>Firearms4</tns:Firearms>
  </tns:HazardousGood>
</tns:HazardousGoods>
```

