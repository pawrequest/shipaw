
# Print Manifest Request 1

## Structure

`PrintManifestRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_manifest_request` | [`PrintManifestRequest`](../../doc/models/print-manifest-request.md) | Required | - |

## Example (as XML)

```xml
<PrintManifestRequest1>
  <tns:PrintManifestRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:ManifestNumber>ManifestNumber6</tns:ManifestNumber>
    <tns:PrintFormat>PrintFormat2</tns:PrintFormat>
  </tns:PrintManifestRequest>
</PrintManifestRequest1>
```

