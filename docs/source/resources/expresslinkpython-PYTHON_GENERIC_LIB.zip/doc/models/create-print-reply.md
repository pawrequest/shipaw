
# Create Print Reply

## Structure

`CreatePrintReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_shipment_info_create_print` | [`CompletedShipmentInfoCreatePrint`](../../doc/models/completed-shipment-info-create-print.md) | Optional | - |
| `label` | [`Document`](../../doc/models/document.md) | Optional | - |
| `label_data` | [`ShipmentLabelData`](../../doc/models/shipment-label-data.md) | Optional | - |
| `partner_code` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:CreatePrintReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:CompletedShipmentInfoCreatePrint xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:LeadShipmentNumber>LeadShipmentNumber8</tns:LeadShipmentNumber>
    <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
    <tns:DeliveryDate>2016-03-13</tns:DeliveryDate>
    <tns:Status>Status0</tns:Status>
    <tns:CompletedShipments>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
    </tns:CompletedShipments>
  </tns:CompletedShipmentInfoCreatePrint>
  <tns:Label xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Data>Data2</tns:Data>
  </tns:Label>
  <tns:LabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ParcelLabelData>
      <tns:ParcelNumber>ParcelNumber6</tns:ParcelNumber>
      <tns:ShipmentNumber>ShipmentNumber8</tns:ShipmentNumber>
      <tns:JourneyLeg>JourneyLeg4</tns:JourneyLeg>
      <tns:LabelData>
        <tns:Item>
          <tns:Name>Name2</tns:Name>
          <tns:Data>Data6</tns:Data>
        </tns:Item>
        <tns:Item>
          <tns:Name>Name2</tns:Name>
          <tns:Data>Data6</tns:Data>
        </tns:Item>
      </tns:LabelData>
      <tns:Barcodes>
        <tns:Barcode>
          <tns:Name>Name4</tns:Name>
          <tns:Data>Data8</tns:Data>
        </tns:Barcode>
      </tns:Barcodes>
    </tns:ParcelLabelData>
  </tns:LabelData>
  <tns:PartnerCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PartnerCode8</tns:PartnerCode>
</tns:CreatePrintReply>
```

