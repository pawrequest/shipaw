
# Requested Shipment

## Structure

`RequestedShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `department_id` | `int` | Optional | - |
| `shipment_type` | `str` | Required | - |
| `contract_number` | `str` | Required | - |
| `request_id` | `int` | Optional | - |
| `service_code` | `str` | Required | - |
| `pre_printed` | `bool` | Optional | - |
| `shipping_date` | `date` | Optional | - |
| `job_reference` | `str` | Optional | - |
| `recipient_contact` | [`Contact`](../../doc/models/contact.md) | Required | - |
| `recipient_address` | [`Address`](../../doc/models/address.md) | Required | - |
| `importer_contact` | [`Contact`](../../doc/models/contact.md) | Optional | - |
| `importer_address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `exporter_contact` | [`Contact`](../../doc/models/contact.md) | Optional | - |
| `exporter_address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `sender_contact` | [`Contact`](../../doc/models/contact.md) | Optional | - |
| `sender_address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `total_number_of_parcels` | `int` | Optional | - |
| `total_shipment_weight` | `float` | Optional | - |
| `enhancement` | [`Enhancement`](../../doc/models/enhancement.md) | Optional | - |
| `delivery_options` | [`DeliveryOptions`](../../doc/models/delivery-options.md) | Optional | - |
| `hazardous_goods` | [`HazardousGoods`](../../doc/models/hazardous-goods.md) | Optional | - |
| `returns` | [`Returns`](../../doc/models/returns.md) | Optional | - |
| `drop_off_ind` | `str` | Optional | - |
| `print_own_label` | `bool` | Optional | - |
| `collection_info` | [`CollectionInfo`](../../doc/models/collection-info.md) | Optional | - |
| `international_info` | [`InternationalInfo`](../../doc/models/international-info.md) | Optional | - |
| `reference_number_1` | `str` | Optional | - |
| `reference_number_2` | `str` | Optional | - |
| `reference_number_3` | `str` | Optional | - |
| `reference_number_4` | `str` | Optional | - |
| `reference_number_5` | `str` | Optional | - |
| `special_instructions_1` | `str` | Optional | - |
| `special_instructions_2` | `str` | Optional | - |
| `special_instructions_3` | `str` | Optional | - |
| `special_instructions_4` | `str` | Optional | - |
| `in_bound_contact` | [`Contact`](../../doc/models/contact.md) | Optional | - |
| `in_bound_address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `in_bound_details` | [`InBoundDetails`](../../doc/models/in-bound-details.md) | Optional | - |
| `exchange_instructions_1` | `str` | Optional | - |
| `exchange_instructions_2` | `str` | Optional | - |
| `exchange_instructions_3` | `str` | Optional | - |
| `consignment_handling` | `bool` | Optional | - |

## Example (as XML)

```xml
<tns:RequestedShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:DepartmentId xmlns:tns="http://www.parcelforce.net/ws/ship/v14">156</tns:DepartmentId>
  <tns:ShipmentType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentType4</tns:ShipmentType>
  <tns:ContractNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ContractNumber2</tns:ContractNumber>
  <tns:RequestId xmlns:tns="http://www.parcelforce.net/ws/ship/v14">112</tns:RequestId>
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode0</tns:ServiceCode>
  <tns:PrePrinted xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:PrePrinted>
  <tns:ShippingDate xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13</tns:ShippingDate>
  <tns:JobReference xmlns:tns="http://www.parcelforce.net/ws/ship/v14">JobReference8</tns:JobReference>
  <tns:RecipientContact xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:BusinessName>BusinessName6</tns:BusinessName>
    <tns:ContactName>ContactName4</tns:ContactName>
    <tns:EmailAddress>EmailAddress2</tns:EmailAddress>
    <tns:Telephone>Telephone2</tns:Telephone>
    <tns:Fax>Fax2</tns:Fax>
    <tns:MobilePhone>MobilePhone6</tns:MobilePhone>
  </tns:RecipientContact>
  <tns:RecipientAddress xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:AddressLine1>AddressLine10</tns:AddressLine1>
    <tns:AddressLine2>AddressLine24</tns:AddressLine2>
    <tns:AddressLine3>AddressLine36</tns:AddressLine3>
    <tns:Town>Town8</tns:Town>
    <tns:Postcode>Postcode0</tns:Postcode>
    <tns:Country>Country8</tns:Country>
  </tns:RecipientAddress>
</tns:RequestedShipment>
```

