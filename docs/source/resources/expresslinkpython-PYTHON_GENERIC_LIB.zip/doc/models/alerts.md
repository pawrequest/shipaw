
# Alerts

## Structure

`Alerts`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alert` | [`List[Alert]`](../../doc/models/alert.md) | Required | - |

## Example (as XML)

```xml
<tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alert xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Code>6</tns:Code>
    <tns:Message>Message0</tns:Message>
    <tns:Type>ERROR</tns:Type>
  </tns:Alert>
</tns:Alerts>
```

