
# Mon

## Structure

`Mon`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hours` | [`Hours`](../../doc/models/hours.md) | Optional | - |

## Example (as XML)

```xml
<tns:Mon xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Hours xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Open>Open4</tns:Open>
    <tns:Close>Close4</tns:Close>
    <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
    <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
  </tns:Hours>
</tns:Mon>
```

