
# Parcel

## Structure

`Parcel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `weight` | `float` | Optional | - |
| `length` | `int` | Optional | - |
| `height` | `int` | Optional | - |
| `width` | `int` | Optional | - |
| `purpose_of_shipment` | `str` | Optional | - |
| `invoice_number` | `str` | Optional | - |
| `export_license_number` | `str` | Optional | - |
| `certificate_number` | `str` | Optional | - |
| `content_details` | [`ContentDetails`](../../doc/models/content-details.md) | Optional | - |
| `shipping_cost` | `float` | Optional | - |

## Example (as XML)

```xml
<tns:Parcel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Weight xmlns:tns="http://www.parcelforce.net/ws/ship/v14">182.26</tns:Weight>
  <tns:Length xmlns:tns="http://www.parcelforce.net/ws/ship/v14">142</tns:Length>
  <tns:Height xmlns:tns="http://www.parcelforce.net/ws/ship/v14">246</tns:Height>
  <tns:Width xmlns:tns="http://www.parcelforce.net/ws/ship/v14">126</tns:Width>
  <tns:PurposeOfShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PurposeOfShipment0</tns:PurposeOfShipment>
</tns:Parcel>
```

