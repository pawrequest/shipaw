
# Specified Neighbour

## Structure

`SpecifiedNeighbour`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address` | [`List[Address]`](../../doc/models/address.md) | Optional | - |

## Example (as XML)

```xml
<tns:SpecifiedNeighbour xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Address xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:AddressLine1>AddressLine14</tns:AddressLine1>
    <tns:AddressLine2>AddressLine28</tns:AddressLine2>
    <tns:AddressLine3>AddressLine30</tns:AddressLine3>
    <tns:Town>Town2</tns:Town>
    <tns:Postcode>Postcode4</tns:Postcode>
    <tns:Country>Country2</tns:Country>
  </tns:Address>
  <tns:Address xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:AddressLine1>AddressLine14</tns:AddressLine1>
    <tns:AddressLine2>AddressLine28</tns:AddressLine2>
    <tns:AddressLine3>AddressLine30</tns:AddressLine3>
    <tns:Town>Town2</tns:Town>
    <tns:Postcode>Postcode4</tns:Postcode>
    <tns:Country>Country2</tns:Country>
  </tns:Address>
</tns:SpecifiedNeighbour>
```

