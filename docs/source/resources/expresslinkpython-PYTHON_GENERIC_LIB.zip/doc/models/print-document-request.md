
# Print Document Request

## Structure

`PrintDocumentRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_number` | `str` | Required | - |
| `document_type` | `int` | Required | - |
| `print_format` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:PrintDocumentRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber4</tns:ShipmentNumber>
  <tns:DocumentType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">70</tns:DocumentType>
  <tns:PrintFormat xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PrintFormat6</tns:PrintFormat>
</tns:PrintDocumentRequest>
```

