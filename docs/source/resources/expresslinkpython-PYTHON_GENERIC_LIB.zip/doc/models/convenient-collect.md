
# Convenient Collect

## Structure

`ConvenientCollect`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `postcode` | `str` | Optional | - |
| `post_office` | [`List[PostOffice]`](../../doc/models/post-office.md) | Optional | - |
| `count` | `int` | Optional | - |
| `post_office_id` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:ConvenientCollect xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Postcode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Postcode6</tns:Postcode>
  <tns:PostOffice xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
    <tns:Business>Business6</tns:Business>
    <tns:Address>
      <tns:AddressLine1>AddressLine14</tns:AddressLine1>
      <tns:AddressLine2>AddressLine28</tns:AddressLine2>
      <tns:AddressLine3>AddressLine30</tns:AddressLine3>
      <tns:Town>Town2</tns:Town>
      <tns:Postcode>Postcode4</tns:Postcode>
      <tns:Country>Country2</tns:Country>
    </tns:Address>
    <tns:OpeningHours>
      <tns:Mon>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Mon>
      <tns:Tue>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Tue>
      <tns:Wed>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Wed>
      <tns:Thu>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Thu>
      <tns:Fri>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Fri>
    </tns:OpeningHours>
    <tns:Distance>109.8</tns:Distance>
  </tns:PostOffice>
  <tns:PostOffice xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
    <tns:Business>Business6</tns:Business>
    <tns:Address>
      <tns:AddressLine1>AddressLine14</tns:AddressLine1>
      <tns:AddressLine2>AddressLine28</tns:AddressLine2>
      <tns:AddressLine3>AddressLine30</tns:AddressLine3>
      <tns:Town>Town2</tns:Town>
      <tns:Postcode>Postcode4</tns:Postcode>
      <tns:Country>Country2</tns:Country>
    </tns:Address>
    <tns:OpeningHours>
      <tns:Mon>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Mon>
      <tns:Tue>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Tue>
      <tns:Wed>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Wed>
      <tns:Thu>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Thu>
      <tns:Fri>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Fri>
    </tns:OpeningHours>
    <tns:Distance>109.8</tns:Distance>
  </tns:PostOffice>
  <tns:Count xmlns:tns="http://www.parcelforce.net/ws/ship/v14">220</tns:Count>
  <tns:PostOfficeID xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PostOfficeID2</tns:PostOfficeID>
</tns:ConvenientCollect>
```

