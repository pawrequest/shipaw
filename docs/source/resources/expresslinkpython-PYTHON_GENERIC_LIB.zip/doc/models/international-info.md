
# International Info

Only for international shipments

## Structure

`InternationalInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcels` | [`Parcels`](../../doc/models/parcels.md) | Optional | - |
| `exporter_customs_reference` | `str` | Optional | - |
| `recipient_importer_vat_no` | `str` | Optional | - |
| `original_export_shipment_no` | `str` | Optional | - |
| `documents_only` | `bool` | Optional | - |
| `documents_description` | `str` | Optional | - |
| `value_under_200_us_dollars` | `bool` | Optional | - |
| `shipment_description` | `str` | Optional | - |
| `comments` | `str` | Optional | - |
| `invoice_date` | `date` | Optional | - |
| `terms_of_delivery` | `str` | Optional | - |
| `purchase_order_ref` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:InternationalInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Parcels xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Parcel>
      <tns:Weight>182.26</tns:Weight>
      <tns:Length>142</tns:Length>
      <tns:Height>246</tns:Height>
      <tns:Width>126</tns:Width>
      <tns:PurposeOfShipment>PurposeOfShipment0</tns:PurposeOfShipment>
    </tns:Parcel>
  </tns:Parcels>
  <tns:ExporterCustomsReference xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ExporterCustomsReference4</tns:ExporterCustomsReference>
  <tns:RecipientImporterVatNo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">RecipientImporterVatNo2</tns:RecipientImporterVatNo>
  <tns:OriginalExportShipmentNo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">OriginalExportShipmentNo0</tns:OriginalExportShipmentNo>
  <tns:DocumentsOnly xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:DocumentsOnly>
</tns:InternationalInfo>
```

