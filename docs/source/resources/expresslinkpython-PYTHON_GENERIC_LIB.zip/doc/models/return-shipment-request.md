
# Return Shipment Request

## Structure

`ReturnShipmentRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_number` | `str` | Required | - |
| `collection_time` | [`DateTimeRange`](../../doc/models/date-time-range.md) | Required | - |

## Example (as XML)

```xml
<tns:ReturnShipmentRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber2</tns:ShipmentNumber>
  <tns:CollectionTime xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:From>2016-03-13T12:52:32.123Z</tns:From>
    <tns:To>2016-03-13T12:52:32.123Z</tns:To>
  </tns:CollectionTime>
</tns:ReturnShipmentRequest>
```

