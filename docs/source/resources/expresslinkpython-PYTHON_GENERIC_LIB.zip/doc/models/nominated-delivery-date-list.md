
# Nominated Delivery Date List

## Structure

`NominatedDeliveryDateList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nominated_delivery_date` | `List[date]` | Optional | - |

## Example (as XML)

```xml
<tns:NominatedDeliveryDateList xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:NominatedDeliveryDate xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13</tns:NominatedDeliveryDate>
  <tns:NominatedDeliveryDate xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13</tns:NominatedDeliveryDate>
</tns:NominatedDeliveryDateList>
```

