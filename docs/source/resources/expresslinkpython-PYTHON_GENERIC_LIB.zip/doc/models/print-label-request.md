
# Print Label Request

## Structure

`PrintLabelRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_number` | `str` | Required | - |
| `print_format` | `str` | Optional | - |
| `barcode_format` | `str` | Optional | - |
| `print_type` | [`PrintTypeEnum`](../../doc/models/print-type-enum.md) | Optional | - |

## Example (as XML)

```xml
<tns:PrintLabelRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber2</tns:ShipmentNumber>
  <tns:PrintFormat xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PrintFormat4</tns:PrintFormat>
  <tns:BarcodeFormat xmlns:tns="http://www.parcelforce.net/ws/ship/v14">BarcodeFormat4</tns:BarcodeFormat>
  <tns:PrintType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ALL_PARCELS</tns:PrintType>
</tns:PrintLabelRequest>
```

