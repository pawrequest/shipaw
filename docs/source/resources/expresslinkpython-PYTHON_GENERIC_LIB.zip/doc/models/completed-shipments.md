
# Completed Shipments

## Structure

`CompletedShipments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_shipment` | [`List[CompletedShipment]`](../../doc/models/completed-shipment.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedShipments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:CompletedShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
    <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
    <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
    <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
  </tns:CompletedShipment>
</tns:CompletedShipments>
```

