
# Contact

## Structure

`Contact`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_name` | `str` | Required | - |
| `contact_name` | `str` | Optional | - |
| `email_address` | `str` | Optional | - |
| `telephone` | `str` | Optional | - |
| `fax` | `str` | Optional | - |
| `mobile_phone` | `str` | Optional | - |
| `senders_name` | `str` | Optional | - |
| `notifications` | [`Notifications`](../../doc/models/notifications.md) | Optional | - |

## Example (as XML)

```xml
<tns:Contact xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:BusinessName xmlns:tns="http://www.parcelforce.net/ws/ship/v14">BusinessName8</tns:BusinessName>
  <tns:ContactName xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ContactName4</tns:ContactName>
  <tns:EmailAddress xmlns:tns="http://www.parcelforce.net/ws/ship/v14">EmailAddress4</tns:EmailAddress>
  <tns:Telephone xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Telephone6</tns:Telephone>
  <tns:Fax xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Fax4</tns:Fax>
  <tns:MobilePhone xmlns:tns="http://www.parcelforce.net/ws/ship/v14">MobilePhone8</tns:MobilePhone>
</tns:Contact>
```

