
# Returns

## Structure

`Returns`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `returns_email` | `str` | Optional | - |
| `email_message` | `str` | Optional | - |
| `email_label` | `bool` | Required | - |

## Example (as XML)

```xml
<tns:Returns xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ReturnsEmail xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ReturnsEmail4</tns:ReturnsEmail>
  <tns:EmailMessage xmlns:tns="http://www.parcelforce.net/ws/ship/v14">EmailMessage0</tns:EmailMessage>
  <tns:EmailLabel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:EmailLabel>
</tns:Returns>
```

