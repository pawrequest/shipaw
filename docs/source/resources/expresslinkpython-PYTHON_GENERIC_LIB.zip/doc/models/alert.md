
# Alert

## Structure

`Alert`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `int` | Required | - |
| `message` | `str` | Required | - |
| `mtype` | [`AlertTypeEnum`](../../doc/models/alert-type-enum.md) | Required | - |

## Example (as XML)

```xml
<tns:Alert xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Code xmlns:tns="http://www.parcelforce.net/ws/ship/v14">6</tns:Code>
  <tns:Message xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Message0</tns:Message>
  <tns:Type xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ERROR</tns:Type>
</tns:Alert>
```

