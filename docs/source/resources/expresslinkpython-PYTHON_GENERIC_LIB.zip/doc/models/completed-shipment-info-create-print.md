
# Completed Shipment Info Create Print

## Structure

`CompletedShipmentInfoCreatePrint`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lead_shipment_number` | `str` | Optional | - |
| `shipment_number` | `str` | Optional | - |
| `delivery_date` | `date` | Optional | - |
| `status` | `str` | Required | - |
| `completed_shipments` | [`CompletedShipments`](../../doc/models/completed-shipments.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedShipmentInfoCreatePrint xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Status xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Status0</tns:Status>
  <tns:CompletedShipments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:CompletedShipment>
      <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
      <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
      <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
      <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
    </tns:CompletedShipment>
  </tns:CompletedShipments>
  <tns:LeadShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">LeadShipmentNumber8</tns:LeadShipmentNumber>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber2</tns:ShipmentNumber>
  <tns:DeliveryDate xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13</tns:DeliveryDate>
</tns:CompletedShipmentInfoCreatePrint>
```

