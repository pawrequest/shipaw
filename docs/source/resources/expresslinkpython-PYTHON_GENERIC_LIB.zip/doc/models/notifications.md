
# Notifications

## Structure

`Notifications`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notification_type` | `List[str]` | Required | - |

## Example (as XML)

```xml
<tns:Notifications xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:NotificationType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">NotificationType2</tns:NotificationType>
  <tns:NotificationType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">NotificationType3</tns:NotificationType>
  <tns:NotificationType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">NotificationType4</tns:NotificationType>
</tns:Notifications>
```

