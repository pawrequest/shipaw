
# Completed Manifests

## Structure

`CompletedManifests`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_manifest_info` | [`List[CompletedManifestInfo]`](../../doc/models/completed-manifest-info.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedManifests xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:CompletedManifestInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:DepartmentId>28</tns:DepartmentId>
    <tns:ManifestNumber>ManifestNumber8</tns:ManifestNumber>
    <tns:ManifestType>ManifestType4</tns:ManifestType>
    <tns:TotalShipmentCount>186</tns:TotalShipmentCount>
    <tns:ManifestShipments>
      <tns:ManifestShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
      </tns:ManifestShipment>
    </tns:ManifestShipments>
  </tns:CompletedManifestInfo>
</tns:CompletedManifests>
```

