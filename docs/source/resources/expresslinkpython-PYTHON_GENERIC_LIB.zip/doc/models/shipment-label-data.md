
# Shipment Label Data

## Structure

`ShipmentLabelData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_label_data` | [`List[ParcelLabelData]`](../../doc/models/parcel-label-data.md) | Required | - |

## Example (as XML)

```xml
<tns:ShipmentLabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ParcelLabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ParcelNumber>ParcelNumber6</tns:ParcelNumber>
    <tns:ShipmentNumber>ShipmentNumber8</tns:ShipmentNumber>
    <tns:JourneyLeg>JourneyLeg4</tns:JourneyLeg>
    <tns:LabelData>
      <tns:Item>
        <tns:Name>Name2</tns:Name>
        <tns:Data>Data6</tns:Data>
      </tns:Item>
      <tns:Item>
        <tns:Name>Name2</tns:Name>
        <tns:Data>Data6</tns:Data>
      </tns:Item>
    </tns:LabelData>
    <tns:Barcodes>
      <tns:Barcode>
        <tns:Name>Name4</tns:Name>
        <tns:Data>Data8</tns:Data>
      </tns:Barcode>
    </tns:Barcodes>
  </tns:ParcelLabelData>
</tns:ShipmentLabelData>
```

