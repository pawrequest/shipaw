
# Completed Shipment

## Structure

`CompletedShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_number` | `str` | Optional | - |
| `out_bound_shipment_number` | `str` | Optional | - |
| `in_bound_shipment_number` | `str` | Optional | - |
| `partner_number` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:CompletedShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber2</tns:ShipmentNumber>
  <tns:OutBoundShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
  <tns:InBoundShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">InBoundShipmentNumber8</tns:InBoundShipmentNumber>
  <tns:PartnerNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PartnerNumber8</tns:PartnerNumber>
</tns:CompletedShipment>
```

