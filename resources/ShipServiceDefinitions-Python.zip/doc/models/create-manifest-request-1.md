
# Create Manifest Request 1

## Structure

`CreateManifestRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `create_manifest_request` | [`CreateManifestRequest`](../../doc/models/create-manifest-request.md) | Required | - |

## Example (as XML)

```xml
<CreateManifestRequest1>
  <tns:CreateManifestRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:DepartmentId>122</tns:DepartmentId>
  </tns:CreateManifestRequest>
</CreateManifestRequest1>
```

