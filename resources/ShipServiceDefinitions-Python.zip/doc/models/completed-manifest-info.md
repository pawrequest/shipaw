
# Completed Manifest Info

## Structure

`CompletedManifestInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `department_id` | `int` | Required | - |
| `manifest_number` | `str` | Required | - |
| `manifest_type` | `str` | Required | - |
| `total_shipment_count` | `int` | Required | - |
| `manifest_shipments` | [`ManifestShipments`](../../doc/models/manifest-shipments.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedManifestInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:DepartmentId xmlns:tns="http://www.parcelforce.net/ws/ship/v14">28</tns:DepartmentId>
  <tns:ManifestNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ManifestNumber8</tns:ManifestNumber>
  <tns:ManifestType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ManifestType4</tns:ManifestType>
  <tns:TotalShipmentCount xmlns:tns="http://www.parcelforce.net/ws/ship/v14">186</tns:TotalShipmentCount>
  <tns:ManifestShipments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ManifestShipment>
      <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
      <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
    </tns:ManifestShipment>
  </tns:ManifestShipments>
</tns:CompletedManifestInfo>
```

