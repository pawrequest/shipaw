
# Print Manifest Reply

## Structure

`PrintManifestReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manifest` | [`Document`](../../doc/models/document.md) | Optional | - |

## Example (as XML)

```xml
<tns:PrintManifestReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:Manifest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Data>Data0</tns:Data>
  </tns:Manifest>
</tns:PrintManifestReply>
```

