
# Cancel Shipment Request 1

## Structure

`CancelShipmentRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel_shipment_request` | [`CancelShipmentRequest`](../../doc/models/cancel-shipment-request.md) | Required | - |

## Example (as XML)

```xml
<CancelShipmentRequest1>
  <tns:CancelShipmentRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:ShipmentNumber>ShipmentNumber4</tns:ShipmentNumber>
  </tns:CancelShipmentRequest>
</CancelShipmentRequest1>
```

