
# Create Shipment Reply

## Structure

`CreateShipmentReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_shipment_info` | [`CompletedShipmentInfo`](../../doc/models/completed-shipment-info.md) | Optional | - |

## Example (as XML)

```xml
<tns:CreateShipmentReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:CompletedShipmentInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:LeadShipmentNumber>LeadShipmentNumber2</tns:LeadShipmentNumber>
    <tns:DeliveryDate>2016-03-13</tns:DeliveryDate>
    <tns:Status>Status0</tns:Status>
    <tns:CompletedShipments>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
      <tns:CompletedShipment>
        <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
        <tns:OutBoundShipmentNumber>OutBoundShipmentNumber8</tns:OutBoundShipmentNumber>
        <tns:InBoundShipmentNumber>InBoundShipmentNumber8</tns:InBoundShipmentNumber>
        <tns:PartnerNumber>PartnerNumber8</tns:PartnerNumber>
      </tns:CompletedShipment>
    </tns:CompletedShipments>
    <tns:RequestedShipment>
      <tns:DepartmentId>156</tns:DepartmentId>
      <tns:ShipmentType>ShipmentType4</tns:ShipmentType>
      <tns:ContractNumber>ContractNumber2</tns:ContractNumber>
      <tns:RequestId>112</tns:RequestId>
      <tns:ServiceCode>ServiceCode0</tns:ServiceCode>
      <tns:PrePrinted>false</tns:PrePrinted>
      <tns:ShippingDate>2016-03-13</tns:ShippingDate>
      <tns:JobReference>JobReference8</tns:JobReference>
      <tns:RecipientContact>
        <tns:BusinessName>BusinessName6</tns:BusinessName>
        <tns:ContactName>ContactName4</tns:ContactName>
        <tns:EmailAddress>EmailAddress2</tns:EmailAddress>
        <tns:Telephone>Telephone2</tns:Telephone>
        <tns:Fax>Fax2</tns:Fax>
        <tns:MobilePhone>MobilePhone6</tns:MobilePhone>
      </tns:RecipientContact>
      <tns:RecipientAddress>
        <tns:AddressLine1>AddressLine10</tns:AddressLine1>
        <tns:AddressLine2>AddressLine24</tns:AddressLine2>
        <tns:AddressLine3>AddressLine36</tns:AddressLine3>
        <tns:Town>Town8</tns:Town>
        <tns:Postcode>Postcode0</tns:Postcode>
        <tns:Country>Country8</tns:Country>
      </tns:RecipientAddress>
    </tns:RequestedShipment>
  </tns:CompletedShipmentInfo>
</tns:CreateShipmentReply>
```

