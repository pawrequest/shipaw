
# Completed Cancel

## Structure

`CompletedCancel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_cancel_info` | [`CompletedCancelInfo`](../../doc/models/completed-cancel-info.md) | Optional | - |

## Example (as XML)

```xml
<tns:CompletedCancel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:CompletedCancelInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Status>Status4</tns:Status>
    <tns:ShipmentNumber>ShipmentNumber6</tns:ShipmentNumber>
  </tns:CompletedCancelInfo>
</tns:CompletedCancel>
```

