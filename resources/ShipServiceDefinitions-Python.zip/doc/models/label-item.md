
# Label Item

## Structure

`LabelItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | - |
| `data` | `str` | Required | - |

## Example (as XML)

```xml
<tns:LabelItem xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Name xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Name0</tns:Name>
  <tns:Data xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Data4</tns:Data>
</tns:LabelItem>
```

