
# Opening Hours

## Structure

`OpeningHours`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mon` | [`Mon`](../../doc/models/mon.md) | Optional | - |
| `tue` | [`Tue`](../../doc/models/tue.md) | Optional | - |
| `wed` | [`Wed`](../../doc/models/wed.md) | Optional | - |
| `thu` | [`Thu`](../../doc/models/thu.md) | Optional | - |
| `fri` | [`Fri`](../../doc/models/fri.md) | Optional | - |
| `sat` | [`Sat`](../../doc/models/sat.md) | Optional | - |
| `sun` | [`Sun`](../../doc/models/sun.md) | Optional | - |
| `bank_hol` | [`BankHol`](../../doc/models/bank-hol.md) | Optional | - |

## Example (as XML)

```xml
<tns:OpeningHours xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Mon xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Hours>
      <tns:Open>Open4</tns:Open>
      <tns:Close>Close4</tns:Close>
      <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
      <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
    </tns:Hours>
  </tns:Mon>
  <tns:Tue xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Hours>
      <tns:Open>Open4</tns:Open>
      <tns:Close>Close4</tns:Close>
      <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
      <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
    </tns:Hours>
  </tns:Tue>
  <tns:Wed xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Hours>
      <tns:Open>Open4</tns:Open>
      <tns:Close>Close4</tns:Close>
      <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
      <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
    </tns:Hours>
  </tns:Wed>
  <tns:Thu xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Hours>
      <tns:Open>Open4</tns:Open>
      <tns:Close>Close4</tns:Close>
      <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
      <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
    </tns:Hours>
  </tns:Thu>
  <tns:Fri xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Hours>
      <tns:Open>Open4</tns:Open>
      <tns:Close>Close4</tns:Close>
      <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
      <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
    </tns:Hours>
  </tns:Fri>
</tns:OpeningHours>
```

