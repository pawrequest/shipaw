
# Authentication

## Structure

`Authentication`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_name` | `str` | Required | - |
| `password` | `str` | Required | - |

## Example (as XML)

```xml
<tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:UserName xmlns:tns="http://www.parcelforce.net/ws/ship/v14">UserName4</tns:UserName>
  <tns:Password xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Password8</tns:Password>
</tns:Authentication>
```

