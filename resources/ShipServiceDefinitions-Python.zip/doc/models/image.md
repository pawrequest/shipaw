
# Image

## Structure

`Image`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | - |
| `data` | `binary` | Required | - |

## Example (as XML)

```xml
<tns:Image xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Name xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Name6</tns:Name>
  <tns:Data xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Data0</tns:Data>
</tns:Image>
```

