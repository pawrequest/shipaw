
# Content Detail

## Structure

`ContentDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country_of_manufacture` | `str` | Required | - |
| `country_of_origin` | `str` | Optional | - |
| `manufacturers_name` | `str` | Optional | - |
| `description` | `str` | Required | - |
| `unit_weight` | `float` | Required | - |
| `unit_quantity` | `int` | Required | - |
| `unit_value` | `float` | Required | - |
| `currency` | `str` | Required | - |
| `tariff_code` | `str` | Optional | - |
| `tariff_description` | `str` | Optional | - |
| `article_reference` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:ContentDetail xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:CountryOfManufacture xmlns:tns="http://www.parcelforce.net/ws/ship/v14">CountryOfManufacture0</tns:CountryOfManufacture>
  <tns:CountryOfOrigin xmlns:tns="http://www.parcelforce.net/ws/ship/v14">CountryOfOrigin2</tns:CountryOfOrigin>
  <tns:ManufacturersName xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ManufacturersName2</tns:ManufacturersName>
  <tns:Description xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Description2</tns:Description>
  <tns:UnitWeight xmlns:tns="http://www.parcelforce.net/ws/ship/v14">127.88</tns:UnitWeight>
  <tns:UnitQuantity xmlns:tns="http://www.parcelforce.net/ws/ship/v14">198</tns:UnitQuantity>
  <tns:UnitValue xmlns:tns="http://www.parcelforce.net/ws/ship/v14">157.56</tns:UnitValue>
  <tns:Currency xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Currency2</tns:Currency>
  <tns:TariffCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">TariffCode6</tns:TariffCode>
  <tns:TariffDescription xmlns:tns="http://www.parcelforce.net/ws/ship/v14">TariffDescription0</tns:TariffDescription>
  <tns:ArticleReference xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ArticleReference4</tns:ArticleReference>
</tns:ContentDetail>
```

