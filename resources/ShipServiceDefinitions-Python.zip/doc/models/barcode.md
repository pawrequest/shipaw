
# Barcode

## Structure

`Barcode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | - |
| `data` | `binary` | Required | - |

## Example (as XML)

```xml
<tns:Barcode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Name xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Name4</tns:Name>
  <tns:Data xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Data8</tns:Data>
</tns:Barcode>
```

