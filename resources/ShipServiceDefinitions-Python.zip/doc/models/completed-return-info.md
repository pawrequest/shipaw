
# Completed Return Info

## Structure

`CompletedReturnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `str` | Required | - |
| `shipment_number` | `str` | Required | - |
| `collection_time` | [`DateTimeRange`](../../doc/models/date-time-range.md) | Required | - |

## Example (as XML)

```xml
<tns:CompletedReturnInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Status xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Status4</tns:Status>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber6</tns:ShipmentNumber>
  <tns:CollectionTime xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:From>2016-03-13T12:52:32.123Z</tns:From>
    <tns:To>2016-03-13T12:52:32.123Z</tns:To>
  </tns:CollectionTime>
</tns:CompletedReturnInfo>
```

