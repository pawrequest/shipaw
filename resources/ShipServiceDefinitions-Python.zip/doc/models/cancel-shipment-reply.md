
# Cancel Shipment Reply

## Structure

`CancelShipmentReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `completed_cancel` | [`CompletedCancel`](../../doc/models/completed-cancel.md) | Optional | - |

## Example (as XML)

```xml
<tns:CancelShipmentReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:CompletedCancel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:CompletedCancelInfo>
      <tns:Status>Status4</tns:Status>
      <tns:ShipmentNumber>ShipmentNumber6</tns:ShipmentNumber>
    </tns:CompletedCancelInfo>
  </tns:CompletedCancel>
</tns:CancelShipmentReply>
```

