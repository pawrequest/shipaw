
# Base Request

## Structure

`BaseRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authentication` | [`Authentication`](../../doc/models/authentication.md) | Required | - |

## Example (as XML)

```xml
<tns:BaseRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
</tns:BaseRequest>
```

