
# Date Time Range

## Structure

`DateTimeRange`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mfrom` | `datetime` | Required | - |
| `to` | `datetime` | Required | - |

## Example (as XML)

```xml
<tns:DateTimeRange xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:From xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13T12:52:32.123Z</tns:From>
  <tns:To xmlns:tns="http://www.parcelforce.net/ws/ship/v14">2016-03-13T12:52:32.123Z</tns:To>
</tns:DateTimeRange>
```

