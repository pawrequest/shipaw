
# Parcel Contents

## Structure

`ParcelContents`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | [`List[ContentData]`](../../doc/models/content-data.md) | Required | - |

## Example (as XML)

```xml
<tns:ParcelContents xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Item xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Name>Name2</tns:Name>
    <tns:Data>Data6</tns:Data>
  </tns:Item>
</tns:ParcelContents>
```

