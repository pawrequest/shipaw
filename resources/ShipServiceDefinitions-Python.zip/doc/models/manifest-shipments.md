
# Manifest Shipments

## Structure

`ManifestShipments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manifest_shipment` | [`List[ManifestShipment]`](../../doc/models/manifest-shipment.md) | Required | - |

## Example (as XML)

```xml
<tns:ManifestShipments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ManifestShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
    <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
  </tns:ManifestShipment>
</tns:ManifestShipments>
```

