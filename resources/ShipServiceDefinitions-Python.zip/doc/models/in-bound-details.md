
# In Bound Details

## Structure

`InBoundDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contract_number` | `str` | Required | - |
| `service_code` | `str` | Required | - |
| `total_shipment_weight` | `str` | Optional | - |
| `enhancement` | [`Enhancement`](../../doc/models/enhancement.md) | Optional | - |
| `reference_number_1` | `str` | Optional | - |
| `reference_number_2` | `str` | Optional | - |
| `reference_number_3` | `str` | Optional | - |
| `reference_number_4` | `str` | Optional | - |
| `reference_number_5` | `str` | Optional | - |
| `special_instructions_1` | `str` | Optional | - |
| `special_instructions_2` | `str` | Optional | - |
| `special_instructions_3` | `str` | Optional | - |
| `special_instructions_4` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:InBoundDetails xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ContractNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ContractNumber2</tns:ContractNumber>
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode0</tns:ServiceCode>
  <tns:TotalShipmentWeight xmlns:tns="http://www.parcelforce.net/ws/ship/v14">TotalShipmentWeight2</tns:TotalShipmentWeight>
  <tns:Enhancement xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:EnhancedCompensation>EnhancedCompensation2</tns:EnhancedCompensation>
    <tns:SaturdayDeliveryRequired>false</tns:SaturdayDeliveryRequired>
  </tns:Enhancement>
  <tns:ReferenceNumber1 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ReferenceNumber16</tns:ReferenceNumber1>
  <tns:ReferenceNumber2 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ReferenceNumber22</tns:ReferenceNumber2>
  <tns:ReferenceNumber3 xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ReferenceNumber34</tns:ReferenceNumber3>
</tns:InBoundDetails>
```

