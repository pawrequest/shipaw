
# Create Manifest Reply 1

## Structure

`CreateManifestReply1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `create_manifest_reply` | [`CreateManifestReply`](../../doc/models/create-manifest-reply.md) | Required | - |

## Example (as XML)

```xml
<CreateManifestReply>
  <CreateManifestReply>
    <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Alert>
        <tns:Code>6</tns:Code>
        <tns:Message>Message0</tns:Message>
        <tns:Type>ERROR</tns:Type>
      </tns:Alert>
    </tns:Alerts>
    <tns:CompletedManifests xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:CompletedManifestInfo>
        <tns:DepartmentId>28</tns:DepartmentId>
        <tns:ManifestNumber>ManifestNumber8</tns:ManifestNumber>
        <tns:ManifestType>ManifestType4</tns:ManifestType>
        <tns:TotalShipmentCount>186</tns:TotalShipmentCount>
        <tns:ManifestShipments>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
        </tns:ManifestShipments>
      </tns:CompletedManifestInfo>
      <tns:CompletedManifestInfo>
        <tns:DepartmentId>28</tns:DepartmentId>
        <tns:ManifestNumber>ManifestNumber8</tns:ManifestNumber>
        <tns:ManifestType>ManifestType4</tns:ManifestType>
        <tns:TotalShipmentCount>186</tns:TotalShipmentCount>
        <tns:ManifestShipments>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
          <tns:ManifestShipment>
            <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
            <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
          </tns:ManifestShipment>
        </tns:ManifestShipments>
      </tns:CompletedManifestInfo>
    </tns:CompletedManifests>
  </CreateManifestReply>
</CreateManifestReply>
```

