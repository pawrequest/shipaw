
# Completed Cancel Info

## Structure

`CompletedCancelInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `str` | Optional | - |
| `shipment_number` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:CompletedCancelInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Status xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Status4</tns:Status>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber6</tns:ShipmentNumber>
</tns:CompletedCancelInfo>
```

