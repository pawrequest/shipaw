
# Post Office

## Structure

`PostOffice`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `post_office_id` | `str` | Optional | - |
| `business` | `str` | Optional | - |
| `address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `opening_hours` | [`OpeningHours`](../../doc/models/opening-hours.md) | Optional | - |
| `distance` | `float` | Optional | - |
| `availability` | `bool` | Optional | - |
| `position` | [`Position`](../../doc/models/position.md) | Optional | - |
| `booking_reference` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:PostOffice xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:PostOfficeID xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PostOfficeID8</tns:PostOfficeID>
  <tns:Business xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Business6</tns:Business>
  <tns:Address xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:AddressLine1>AddressLine14</tns:AddressLine1>
    <tns:AddressLine2>AddressLine28</tns:AddressLine2>
    <tns:AddressLine3>AddressLine30</tns:AddressLine3>
    <tns:Town>Town2</tns:Town>
    <tns:Postcode>Postcode4</tns:Postcode>
    <tns:Country>Country2</tns:Country>
  </tns:Address>
  <tns:OpeningHours xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Mon>
      <tns:Hours>
        <tns:Open>Open4</tns:Open>
        <tns:Close>Close4</tns:Close>
        <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
        <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
      </tns:Hours>
    </tns:Mon>
    <tns:Tue>
      <tns:Hours>
        <tns:Open>Open4</tns:Open>
        <tns:Close>Close4</tns:Close>
        <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
        <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
      </tns:Hours>
    </tns:Tue>
    <tns:Wed>
      <tns:Hours>
        <tns:Open>Open4</tns:Open>
        <tns:Close>Close4</tns:Close>
        <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
        <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
      </tns:Hours>
    </tns:Wed>
    <tns:Thu>
      <tns:Hours>
        <tns:Open>Open4</tns:Open>
        <tns:Close>Close4</tns:Close>
        <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
        <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
      </tns:Hours>
    </tns:Thu>
    <tns:Fri>
      <tns:Hours>
        <tns:Open>Open4</tns:Open>
        <tns:Close>Close4</tns:Close>
        <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
        <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
      </tns:Hours>
    </tns:Fri>
  </tns:OpeningHours>
  <tns:Distance xmlns:tns="http://www.parcelforce.net/ws/ship/v14">109.8</tns:Distance>
</tns:PostOffice>
```

