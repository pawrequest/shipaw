
# Collection Info

Only required for collections

## Structure

`CollectionInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `collection_contact` | [`Contact`](../../doc/models/contact.md) | Required | - |
| `collection_address` | [`Address`](../../doc/models/address.md) | Required | - |
| `collection_time` | [`DateTimeRange`](../../doc/models/date-time-range.md) | Optional | - |

## Example (as XML)

```xml
<tns:CollectionInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:CollectionContact xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:BusinessName>BusinessName4</tns:BusinessName>
    <tns:ContactName>ContactName2</tns:ContactName>
    <tns:EmailAddress>EmailAddress0</tns:EmailAddress>
    <tns:Telephone>Telephone0</tns:Telephone>
    <tns:Fax>Fax0</tns:Fax>
    <tns:MobilePhone>MobilePhone4</tns:MobilePhone>
  </tns:CollectionContact>
  <tns:CollectionAddress xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:AddressLine1>AddressLine14</tns:AddressLine1>
    <tns:AddressLine2>AddressLine20</tns:AddressLine2>
    <tns:AddressLine3>AddressLine38</tns:AddressLine3>
    <tns:Town>Town4</tns:Town>
    <tns:Postcode>Postcode4</tns:Postcode>
    <tns:Country>Country4</tns:Country>
  </tns:CollectionAddress>
  <tns:CollectionTime xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:From>2016-03-13T12:52:32.123Z</tns:From>
    <tns:To>2016-03-13T12:52:32.123Z</tns:To>
  </tns:CollectionTime>
</tns:CollectionInfo>
```

