
# Nominated Delivery Dates

## Structure

`NominatedDeliveryDates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `service_code` | `str` | Optional | - |
| `departments` | [`Departments`](../../doc/models/departments.md) | Optional | - |

## Example (as XML)

```xml
<tns:NominatedDeliveryDates xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode2</tns:ServiceCode>
  <tns:Departments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Department>
      <tns:DepartmentID>138</tns:DepartmentID>
      <tns:DepartmentID>139</tns:DepartmentID>
      <tns:DepartmentID>140</tns:DepartmentID>
      <tns:ServiceCodes>
        <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
        <tns:ServiceCode>ServiceCode3</tns:ServiceCode>
        <tns:ServiceCode>ServiceCode4</tns:ServiceCode>
      </tns:ServiceCodes>
      <tns:NominatedDeliveryDateList>
        <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
        <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
      </tns:NominatedDeliveryDateList>
    </tns:Department>
  </tns:Departments>
</tns:NominatedDeliveryDates>
```

