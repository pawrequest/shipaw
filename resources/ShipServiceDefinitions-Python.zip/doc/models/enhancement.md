
# Enhancement

## Structure

`Enhancement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enhanced_compensation` | `str` | Optional | - |
| `saturday_delivery_required` | `bool` | Optional | - |

## Example (as XML)

```xml
<tns:Enhancement xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:EnhancedCompensation xmlns:tns="http://www.parcelforce.net/ws/ship/v14">EnhancedCompensation2</tns:EnhancedCompensation>
  <tns:SaturdayDeliveryRequired xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:SaturdayDeliveryRequired>
</tns:Enhancement>
```

