
# Hours

## Structure

`Hours`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `open` | `str` | Optional | - |
| `close` | `str` | Optional | - |
| `close_lunch` | `str` | Optional | - |
| `after_lunch_opening` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:Hours xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Open xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Open4</tns:Open>
  <tns:Close xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Close4</tns:Close>
  <tns:CloseLunch xmlns:tns="http://www.parcelforce.net/ws/ship/v14">CloseLunch2</tns:CloseLunch>
  <tns:AfterLunchOpening xmlns:tns="http://www.parcelforce.net/ws/ship/v14">AfterLunchOpening0</tns:AfterLunchOpening>
</tns:Hours>
```

