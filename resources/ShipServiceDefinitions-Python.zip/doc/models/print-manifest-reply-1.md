
# Print Manifest Reply 1

## Structure

`PrintManifestReply1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_manifest_reply` | [`PrintManifestReply`](../../doc/models/print-manifest-reply.md) | Required | - |

## Example (as XML)

```xml
<PrintManifestReply>
  <PrintManifestReply>
    <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Alert>
        <tns:Code>6</tns:Code>
        <tns:Message>Message0</tns:Message>
        <tns:Type>ERROR</tns:Type>
      </tns:Alert>
    </tns:Alerts>
    <tns:Manifest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Data>Data0</tns:Data>
    </tns:Manifest>
  </PrintManifestReply>
</PrintManifestReply>
```

