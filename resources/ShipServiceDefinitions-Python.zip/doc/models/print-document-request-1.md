
# Print Document Request 1

## Structure

`PrintDocumentRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `print_document_request` | [`PrintDocumentRequest`](../../doc/models/print-document-request.md) | Required | - |

## Example (as XML)

```xml
<PrintDocumentRequest1>
  <tns:PrintDocumentRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:ShipmentNumber>ShipmentNumber4</tns:ShipmentNumber>
    <tns:DocumentType>70</tns:DocumentType>
    <tns:PrintFormat>PrintFormat6</tns:PrintFormat>
  </tns:PrintDocumentRequest>
</PrintDocumentRequest1>
```

