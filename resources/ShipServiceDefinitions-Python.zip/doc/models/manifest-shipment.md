
# Manifest Shipment

## Structure

`ManifestShipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipment_number` | `str` | Required | - |
| `service_code` | `str` | Required | - |

## Example (as XML)

```xml
<tns:ManifestShipment xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber2</tns:ShipmentNumber>
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode2</tns:ServiceCode>
</tns:ManifestShipment>
```

