
# Parcel Label Data

## Structure

`ParcelLabelData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel_number` | `str` | Optional | - |
| `shipment_number` | `str` | Optional | - |
| `journey_leg` | `str` | Optional | - |
| `label_data` | [`LabelData`](../../doc/models/label-data.md) | Optional | - |
| `barcodes` | [`Barcodes`](../../doc/models/barcodes.md) | Optional | - |
| `images` | [`Images`](../../doc/models/images.md) | Optional | - |
| `parcel_contents` | [`List[ParcelContents]`](../../doc/models/parcel-contents.md) | Optional | - |

## Example (as XML)

```xml
<tns:ParcelLabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ParcelNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ParcelNumber6</tns:ParcelNumber>
  <tns:ShipmentNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ShipmentNumber8</tns:ShipmentNumber>
  <tns:JourneyLeg xmlns:tns="http://www.parcelforce.net/ws/ship/v14">JourneyLeg4</tns:JourneyLeg>
  <tns:LabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Item>
      <tns:Name>Name2</tns:Name>
      <tns:Data>Data6</tns:Data>
    </tns:Item>
    <tns:Item>
      <tns:Name>Name2</tns:Name>
      <tns:Data>Data6</tns:Data>
    </tns:Item>
  </tns:LabelData>
  <tns:Barcodes xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Barcode>
      <tns:Name>Name4</tns:Name>
      <tns:Data>Data8</tns:Data>
    </tns:Barcode>
  </tns:Barcodes>
</tns:ParcelLabelData>
```

