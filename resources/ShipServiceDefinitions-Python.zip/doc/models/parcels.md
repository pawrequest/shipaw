
# Parcels

## Structure

`Parcels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parcel` | [`List[Parcel]`](../../doc/models/parcel.md) | Required | - |

## Example (as XML)

```xml
<tns:Parcels xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Parcel xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Weight>182.26</tns:Weight>
    <tns:Length>142</tns:Length>
    <tns:Height>246</tns:Height>
    <tns:Width>126</tns:Width>
    <tns:PurposeOfShipment>PurposeOfShipment0</tns:PurposeOfShipment>
  </tns:Parcel>
</tns:Parcels>
```

