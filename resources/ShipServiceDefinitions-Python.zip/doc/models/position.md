
# Position

## Structure

`Position`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `longitude` | `float` | Optional | - |
| `latitude` | `float` | Optional | - |

## Example (as XML)

```xml
<tns:Position xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Longitude xmlns:tns="http://www.parcelforce.net/ws/ship/v14">196.02</tns:Longitude>
  <tns:Latitude xmlns:tns="http://www.parcelforce.net/ws/ship/v14">127.54</tns:Latitude>
</tns:Position>
```

