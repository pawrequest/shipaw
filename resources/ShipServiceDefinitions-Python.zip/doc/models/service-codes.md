
# Service Codes

## Structure

`ServiceCodes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `service_code` | `List[str]` | Optional | - |

## Example (as XML)

```xml
<tns:ServiceCodes xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode2</tns:ServiceCode>
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode3</tns:ServiceCode>
  <tns:ServiceCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ServiceCode4</tns:ServiceCode>
</tns:ServiceCodes>
```

