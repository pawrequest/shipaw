
# Alert Type Enum

## Enumeration

`AlertTypeEnum`

## Fields

| Name |
|  --- |
| `ERROR` |
| `WARNING` |
| `NOTIFICATION` |

