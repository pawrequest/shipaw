
# Create Shipment Request 1

## Structure

`CreateShipmentRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `create_shipment_request` | [`CreateShipmentRequest`](../../doc/models/create-shipment-request.md) | Required | - |

## Example (as XML)

```xml
<CreateShipmentRequest1>
  <tns:CreateShipmentRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:RequestedShipment>
      <tns:DepartmentId>156</tns:DepartmentId>
      <tns:ShipmentType>ShipmentType4</tns:ShipmentType>
      <tns:ContractNumber>ContractNumber2</tns:ContractNumber>
      <tns:RequestId>112</tns:RequestId>
      <tns:ServiceCode>ServiceCode0</tns:ServiceCode>
      <tns:PrePrinted>false</tns:PrePrinted>
      <tns:ShippingDate>2016-03-13</tns:ShippingDate>
      <tns:JobReference>JobReference8</tns:JobReference>
      <tns:RecipientContact>
        <tns:BusinessName>BusinessName6</tns:BusinessName>
        <tns:ContactName>ContactName4</tns:ContactName>
        <tns:EmailAddress>EmailAddress2</tns:EmailAddress>
        <tns:Telephone>Telephone2</tns:Telephone>
        <tns:Fax>Fax2</tns:Fax>
        <tns:MobilePhone>MobilePhone6</tns:MobilePhone>
      </tns:RecipientContact>
      <tns:RecipientAddress>
        <tns:AddressLine1>AddressLine10</tns:AddressLine1>
        <tns:AddressLine2>AddressLine24</tns:AddressLine2>
        <tns:AddressLine3>AddressLine36</tns:AddressLine3>
        <tns:Town>Town8</tns:Town>
        <tns:Postcode>Postcode0</tns:Postcode>
        <tns:Country>Country8</tns:Country>
      </tns:RecipientAddress>
    </tns:RequestedShipment>
  </tns:CreateShipmentRequest>
</CreateShipmentRequest1>
```

