
# CC Reserve Reply

## Structure

`CCReserveReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `post_office` | [`PostOffice`](../../doc/models/post-office.md) | Optional | - |

## Example (as XML)

```xml
<tns:CCReserveReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:PostOffice xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
    <tns:Business>Business6</tns:Business>
    <tns:Address>
      <tns:AddressLine1>AddressLine14</tns:AddressLine1>
      <tns:AddressLine2>AddressLine28</tns:AddressLine2>
      <tns:AddressLine3>AddressLine30</tns:AddressLine3>
      <tns:Town>Town2</tns:Town>
      <tns:Postcode>Postcode4</tns:Postcode>
      <tns:Country>Country2</tns:Country>
    </tns:Address>
    <tns:OpeningHours>
      <tns:Mon>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Mon>
      <tns:Tue>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Tue>
      <tns:Wed>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Wed>
      <tns:Thu>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Thu>
      <tns:Fri>
        <tns:Hours>
          <tns:Open>Open4</tns:Open>
          <tns:Close>Close4</tns:Close>
          <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
          <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
        </tns:Hours>
      </tns:Fri>
    </tns:OpeningHours>
    <tns:Distance>109.8</tns:Distance>
  </tns:PostOffice>
</tns:CCReserveReply>
```

