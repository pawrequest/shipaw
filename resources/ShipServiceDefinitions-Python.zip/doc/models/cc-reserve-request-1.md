
# CC Reserve Request 1

## Structure

`CCReserveRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cc_reserve_request` | [`CCReserveRequest`](../../doc/models/cc-reserve-request.md) | Required | - |

## Example (as XML)

```xml
<CCReserveRequest1>
  <tns:CCReserveRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Authentication>
      <tns:UserName>UserName4</tns:UserName>
      <tns:Password>Password8</tns:Password>
    </tns:Authentication>
    <tns:BookingReference>BookingReference6</tns:BookingReference>
  </tns:CCReserveRequest>
</CCReserveRequest1>
```

