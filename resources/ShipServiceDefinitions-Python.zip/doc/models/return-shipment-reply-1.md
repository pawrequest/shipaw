
# Return Shipment Reply 1

## Structure

`ReturnShipmentReply1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `return_shipment_reply` | [`ReturnShipmentReply`](../../doc/models/return-shipment-reply.md) | Required | - |

## Example (as XML)

```xml
<ReturnShipmentReply>
  <ReturnShipmentReply>
    <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Alert>
        <tns:Code>6</tns:Code>
        <tns:Message>Message0</tns:Message>
        <tns:Type>ERROR</tns:Type>
      </tns:Alert>
    </tns:Alerts>
    <tns:CompletedShipmentInfo xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
      <tns:Status>Status0</tns:Status>
      <tns:ShipmentNumber>ShipmentNumber2</tns:ShipmentNumber>
      <tns:CollectionTime>
        <tns:From>2016-03-13T12:52:32.123Z</tns:From>
        <tns:To>2016-03-13T12:52:32.123Z</tns:To>
      </tns:CollectionTime>
    </tns:CompletedShipmentInfo>
  </ReturnShipmentReply>
</ReturnShipmentReply>
```

