
# Print Manifest Request

## Structure

`PrintManifestRequest`

## Inherits From

[`BaseRequest`](../../doc/models/base-request.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manifest_number` | `str` | Required | - |
| `print_format` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:PrintManifestRequest xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Authentication xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:UserName>UserName4</tns:UserName>
    <tns:Password>Password8</tns:Password>
  </tns:Authentication>
  <tns:ManifestNumber xmlns:tns="http://www.parcelforce.net/ws/ship/v14">ManifestNumber6</tns:ManifestNumber>
  <tns:PrintFormat xmlns:tns="http://www.parcelforce.net/ws/ship/v14">PrintFormat2</tns:PrintFormat>
</tns:PrintManifestRequest>
```

