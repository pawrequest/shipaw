
# Departments

## Structure

`Departments`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `department` | [`List[Department]`](../../doc/models/department.md) | Optional | - |

## Example (as XML)

```xml
<tns:Departments xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Department xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:DepartmentID>138</tns:DepartmentID>
    <tns:DepartmentID>139</tns:DepartmentID>
    <tns:DepartmentID>140</tns:DepartmentID>
    <tns:ServiceCodes>
      <tns:ServiceCode>ServiceCode2</tns:ServiceCode>
      <tns:ServiceCode>ServiceCode3</tns:ServiceCode>
      <tns:ServiceCode>ServiceCode4</tns:ServiceCode>
    </tns:ServiceCodes>
    <tns:NominatedDeliveryDateList>
      <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
      <tns:NominatedDeliveryDate>2016-03-13</tns:NominatedDeliveryDate>
    </tns:NominatedDeliveryDateList>
  </tns:Department>
</tns:Departments>
```

