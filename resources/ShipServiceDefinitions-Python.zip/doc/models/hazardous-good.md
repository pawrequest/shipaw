
# Hazardous Good

## Structure

`HazardousGood`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lqdgun_code` | `str` | Optional | - |
| `lqdg_description` | `str` | Optional | - |
| `lqdg_volume` | `float` | Optional | - |
| `firearms` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:HazardousGood xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:LQDGUNCode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">LQDGUNCode8</tns:LQDGUNCode>
  <tns:LQDGDescription xmlns:tns="http://www.parcelforce.net/ws/ship/v14">LQDGDescription6</tns:LQDGDescription>
  <tns:LQDGVolume xmlns:tns="http://www.parcelforce.net/ws/ship/v14">86.12</tns:LQDGVolume>
  <tns:Firearms xmlns:tns="http://www.parcelforce.net/ws/ship/v14">Firearms4</tns:Firearms>
</tns:HazardousGood>
```

