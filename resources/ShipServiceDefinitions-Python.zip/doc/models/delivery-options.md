
# Delivery Options

## Structure

`DeliveryOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `convenient_collect` | [`ConvenientCollect`](../../doc/models/convenient-collect.md) | Optional | - |
| `irts` | `bool` | Optional | - |
| `letterbox` | `bool` | Optional | - |
| `specified_post_office` | [`SpecifiedPostOffice`](../../doc/models/specified-post-office.md) | Optional | - |
| `specified_neighbour` | `str` | Optional | - |
| `safe_place` | `str` | Optional | - |
| `pin` | `int` | Optional | - |
| `named_recipient` | `bool` | Optional | - |
| `address_only` | `bool` | Optional | - |
| `nominated_delivery_date` | `date` | Optional | - |
| `personal_parcel` | `str` | Optional | - |

## Example (as XML)

```xml
<tns:DeliveryOptions xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:ConvenientCollect xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Postcode>Postcode6</tns:Postcode>
    <tns:PostOffice>
      <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
      <tns:Business>Business6</tns:Business>
      <tns:Address>
        <tns:AddressLine1>AddressLine14</tns:AddressLine1>
        <tns:AddressLine2>AddressLine28</tns:AddressLine2>
        <tns:AddressLine3>AddressLine30</tns:AddressLine3>
        <tns:Town>Town2</tns:Town>
        <tns:Postcode>Postcode4</tns:Postcode>
        <tns:Country>Country2</tns:Country>
      </tns:Address>
      <tns:OpeningHours>
        <tns:Mon>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Mon>
        <tns:Tue>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Tue>
        <tns:Wed>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Wed>
        <tns:Thu>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Thu>
        <tns:Fri>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Fri>
      </tns:OpeningHours>
      <tns:Distance>109.8</tns:Distance>
    </tns:PostOffice>
    <tns:PostOffice>
      <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
      <tns:Business>Business6</tns:Business>
      <tns:Address>
        <tns:AddressLine1>AddressLine14</tns:AddressLine1>
        <tns:AddressLine2>AddressLine28</tns:AddressLine2>
        <tns:AddressLine3>AddressLine30</tns:AddressLine3>
        <tns:Town>Town2</tns:Town>
        <tns:Postcode>Postcode4</tns:Postcode>
        <tns:Country>Country2</tns:Country>
      </tns:Address>
      <tns:OpeningHours>
        <tns:Mon>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Mon>
        <tns:Tue>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Tue>
        <tns:Wed>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Wed>
        <tns:Thu>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Thu>
        <tns:Fri>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Fri>
      </tns:OpeningHours>
      <tns:Distance>109.8</tns:Distance>
    </tns:PostOffice>
    <tns:Count>220</tns:Count>
    <tns:PostOfficeID>PostOfficeID2</tns:PostOfficeID>
  </tns:ConvenientCollect>
  <tns:IRTS xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:IRTS>
  <tns:Letterbox xmlns:tns="http://www.parcelforce.net/ws/ship/v14">false</tns:Letterbox>
  <tns:SpecifiedPostOffice xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Postcode>Postcode4</tns:Postcode>
    <tns:PostOffice>
      <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
      <tns:Business>Business6</tns:Business>
      <tns:Address>
        <tns:AddressLine1>AddressLine14</tns:AddressLine1>
        <tns:AddressLine2>AddressLine28</tns:AddressLine2>
        <tns:AddressLine3>AddressLine30</tns:AddressLine3>
        <tns:Town>Town2</tns:Town>
        <tns:Postcode>Postcode4</tns:Postcode>
        <tns:Country>Country2</tns:Country>
      </tns:Address>
      <tns:OpeningHours>
        <tns:Mon>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Mon>
        <tns:Tue>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Tue>
        <tns:Wed>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Wed>
        <tns:Thu>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Thu>
        <tns:Fri>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Fri>
      </tns:OpeningHours>
      <tns:Distance>109.8</tns:Distance>
    </tns:PostOffice>
    <tns:PostOffice>
      <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
      <tns:Business>Business6</tns:Business>
      <tns:Address>
        <tns:AddressLine1>AddressLine14</tns:AddressLine1>
        <tns:AddressLine2>AddressLine28</tns:AddressLine2>
        <tns:AddressLine3>AddressLine30</tns:AddressLine3>
        <tns:Town>Town2</tns:Town>
        <tns:Postcode>Postcode4</tns:Postcode>
        <tns:Country>Country2</tns:Country>
      </tns:Address>
      <tns:OpeningHours>
        <tns:Mon>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Mon>
        <tns:Tue>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Tue>
        <tns:Wed>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Wed>
        <tns:Thu>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Thu>
        <tns:Fri>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Fri>
      </tns:OpeningHours>
      <tns:Distance>109.8</tns:Distance>
    </tns:PostOffice>
    <tns:PostOffice>
      <tns:PostOfficeID>PostOfficeID8</tns:PostOfficeID>
      <tns:Business>Business6</tns:Business>
      <tns:Address>
        <tns:AddressLine1>AddressLine14</tns:AddressLine1>
        <tns:AddressLine2>AddressLine28</tns:AddressLine2>
        <tns:AddressLine3>AddressLine30</tns:AddressLine3>
        <tns:Town>Town2</tns:Town>
        <tns:Postcode>Postcode4</tns:Postcode>
        <tns:Country>Country2</tns:Country>
      </tns:Address>
      <tns:OpeningHours>
        <tns:Mon>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Mon>
        <tns:Tue>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Tue>
        <tns:Wed>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Wed>
        <tns:Thu>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Thu>
        <tns:Fri>
          <tns:Hours>
            <tns:Open>Open4</tns:Open>
            <tns:Close>Close4</tns:Close>
            <tns:CloseLunch>CloseLunch2</tns:CloseLunch>
            <tns:AfterLunchOpening>AfterLunchOpening0</tns:AfterLunchOpening>
          </tns:Hours>
        </tns:Fri>
      </tns:OpeningHours>
      <tns:Distance>109.8</tns:Distance>
    </tns:PostOffice>
    <tns:Count>168</tns:Count>
    <tns:PostOfficeID>PostOfficeID6</tns:PostOfficeID>
  </tns:SpecifiedPostOffice>
  <tns:SpecifiedNeighbour xmlns:tns="http://www.parcelforce.net/ws/ship/v14">SpecifiedNeighbour4</tns:SpecifiedNeighbour>
</tns:DeliveryOptions>
```

