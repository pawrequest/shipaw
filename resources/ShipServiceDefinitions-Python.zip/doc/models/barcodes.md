
# Barcodes

## Structure

`Barcodes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `barcode` | [`List[Barcode]`](../../doc/models/barcode.md) | Required | - |

## Example (as XML)

```xml
<tns:Barcodes xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Barcode xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Name>Name4</tns:Name>
    <tns:Data>Data8</tns:Data>
  </tns:Barcode>
</tns:Barcodes>
```

