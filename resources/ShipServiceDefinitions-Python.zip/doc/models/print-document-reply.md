
# Print Document Reply

## Structure

`PrintDocumentReply`

## Inherits From

[`BaseReply`](../../doc/models/base-reply.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | [`Document`](../../doc/models/document.md) | Optional | - |
| `label_data` | [`ShipmentLabelData`](../../doc/models/shipment-label-data.md) | Optional | - |
| `document_type` | [`Document`](../../doc/models/document.md) | Optional | - |

## Example (as XML)

```xml
<tns:PrintDocumentReply xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
  <tns:Alerts xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Alert>
      <tns:Code>6</tns:Code>
      <tns:Message>Message0</tns:Message>
      <tns:Type>ERROR</tns:Type>
    </tns:Alert>
  </tns:Alerts>
  <tns:Label xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Data>Data2</tns:Data>
  </tns:Label>
  <tns:LabelData xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:ParcelLabelData>
      <tns:ParcelNumber>ParcelNumber6</tns:ParcelNumber>
      <tns:ShipmentNumber>ShipmentNumber8</tns:ShipmentNumber>
      <tns:JourneyLeg>JourneyLeg4</tns:JourneyLeg>
      <tns:LabelData>
        <tns:Item>
          <tns:Name>Name2</tns:Name>
          <tns:Data>Data6</tns:Data>
        </tns:Item>
        <tns:Item>
          <tns:Name>Name2</tns:Name>
          <tns:Data>Data6</tns:Data>
        </tns:Item>
      </tns:LabelData>
      <tns:Barcodes>
        <tns:Barcode>
          <tns:Name>Name4</tns:Name>
          <tns:Data>Data8</tns:Data>
        </tns:Barcode>
      </tns:Barcodes>
    </tns:ParcelLabelData>
  </tns:LabelData>
  <tns:DocumentType xmlns:tns="http://www.parcelforce.net/ws/ship/v14">
    <tns:Data>Data4</tns:Data>
  </tns:DocumentType>
</tns:PrintDocumentReply>
```

